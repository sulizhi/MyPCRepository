package com.chelly.mapper;

import com.chelly.entity.Component;
import com.chelly.entity.Componentkind;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Mapper
@Repository
public interface ComponentkindMapper{
    List<Componentkind> getAllComponentkinds();
    void addComponentkind(Componentkind componentkind);
}
