package com.chelly.mapper;

import com.chelly.entity.Projectinfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Mapper
@Repository
public interface ProjectinfoMapper{
    List<Projectinfo> getAllProjects();
    void addProject(Projectinfo projectinfo);
}
