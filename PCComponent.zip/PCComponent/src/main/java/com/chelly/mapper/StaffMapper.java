package com.chelly.mapper;

import com.chelly.entity.Staff;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Mapper
@Repository
public interface StaffMapper{
    Staff getUserByUsername(String username);
}
