package com.chelly.controller;


import com.chelly.entity.Projectinfo;
import com.chelly.mapper.ProjectinfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("projectinfo")
public class ProjectinfoController {
    @Autowired
    public ProjectinfoMapper projectinfoMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<Projectinfo> projectList = projectinfoMapper.getAllProjects();
        model.addAttribute("projects",projectList);
        return "project/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "project/add";
    }

    @RequestMapping("/add")
    public String addEmployee(Projectinfo projectinfo){
        projectinfoMapper.addProject(projectinfo);
        return "redirect:/projectinfo/view";
    }
}
