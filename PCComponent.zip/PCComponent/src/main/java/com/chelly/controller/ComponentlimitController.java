package com.chelly.controller;


import com.chelly.entity.Componentlimit;
import com.chelly.mapper.ComponentlimitMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("componentlimit")
public class ComponentlimitController {
    @Autowired
    public ComponentlimitMapper ComponentlimitMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<Componentlimit> ComponentlimitList = ComponentlimitMapper.getAllComponentlimits();
        model.addAttribute("Componentlimits",ComponentlimitList);
        return "componentlimit/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "componentlimit/add";
    }

    @RequestMapping("/add")
    public String addEmployee(Componentlimit Componentlimit){
        ComponentlimitMapper.addComponentlimit(Componentlimit);
        return "redirect:/componentlimit/view";
    }
}
