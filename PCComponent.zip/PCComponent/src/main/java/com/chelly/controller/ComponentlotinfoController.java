package com.chelly.controller;


import com.chelly.entity.Componentlotinfo;
import com.chelly.mapper.ComponentlotinfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("componentlotinfo")
public class ComponentlotinfoController {
    @Autowired
    public ComponentlotinfoMapper componentlotinfoMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<Componentlotinfo> ComponentlotinfoList = componentlotinfoMapper.getAllComponentlotinfos();
        model.addAttribute("Componentlotinfos",ComponentlotinfoList);
        return "componentlotinfo/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "componentlotinfo/add";
    }

    @RequestMapping("/add")
    public String addEmployee(Componentlotinfo Componentlotinfo){
        componentlotinfoMapper.addComponentlotinfo(Componentlotinfo);
        return "redirect:/componentlotinfo/view";
    }
}
