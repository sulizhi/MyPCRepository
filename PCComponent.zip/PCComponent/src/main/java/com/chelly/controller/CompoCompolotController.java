package com.chelly.controller;


import com.chelly.entity.CompoCompolot;
import com.chelly.mapper.CompoCompolotMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("compoCompolot")
public class CompoCompolotController {
    @Autowired
    public CompoCompolotMapper CompoCompolotMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<CompoCompolot> compoCompolotList = CompoCompolotMapper.getAllCompoCompolots();
        model.addAttribute("compoCompolots",compoCompolotList);
        return "compoCompolot/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "compoCompolot/add";
    }

    @RequestMapping("/add")
    public String addEmployee(CompoCompolot CompoCompolot){
        CompoCompolotMapper.addCompoCompolot(CompoCompolot);
        return "redirect:/compoCompolot/view";
    }
}
