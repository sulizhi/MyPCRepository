package com.chelly.controller;


import com.chelly.entity.Componentkind;
import com.chelly.mapper.ComponentkindMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("componentkind")
public class ComponentkindController {
    @Autowired
    public ComponentkindMapper ComponentkindMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<Componentkind> ComponentkindList = ComponentkindMapper.getAllComponentkinds();
        model.addAttribute("Componentkinds",ComponentkindList);
        return "componentkind/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "componentkind/add";
    }

    @RequestMapping("/add")
    public String addEmployee(Componentkind Componentkind){
        ComponentkindMapper.addComponentkind(Componentkind);
        return "redirect:/componentkind/view";
    }
}
