package com.chelly.controller;


import com.chelly.entity.MenProject;
import com.chelly.mapper.MenProjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 余思
 * @since 2021-06-08
 */
@Controller
@RequestMapping("menProject")
public class MenProjectController {
    @Autowired
    public MenProjectMapper menProjectMapper;

    @RequestMapping("/view")
    public String project(Model model){
        List<MenProject> MenProjectList = menProjectMapper.getAllMenProjects();
        model.addAttribute("MenProjects",MenProjectList);
        return "menProject/list";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model){
        return "menProject/add";
    }

    @RequestMapping("/add")
    public String addEmployee(MenProject MenProject){
        menProjectMapper.addMenProject(MenProject);
        return "redirect:/menProject/view";
    }
}
