package com.chelly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcComponentApplication {

    public static void main(String[] args) {
        SpringApplication.run(PcComponentApplication.class, args);
    }

}
