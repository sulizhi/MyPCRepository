package com.chelly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcComponentApplicationTests {

    @Test
    void contextLoads() {
    }

}
